import React from 'react'
import Header from '../../components/header/Header'

const Home = () => {
  return (
    <div>
        <Header/>
    </div>
  )
}

export default Home